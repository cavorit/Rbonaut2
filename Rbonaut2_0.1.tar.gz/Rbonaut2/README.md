# Rbonaut2 

Rbonaut2 ist eine Neuauflage von Rbonaut. Während Rbonaut noch über Dropbox lief und dabei auf händische Dumps von CGoal angewiesen war, arbeitet Rbonaut2 im Rahmen von CLIP2 mit dem Output von SQL-Dateien.
